# Machine-Learning-Project

Refer Auto_Insurance_Claim_Prediction_Project_Report.pdf for project report.
