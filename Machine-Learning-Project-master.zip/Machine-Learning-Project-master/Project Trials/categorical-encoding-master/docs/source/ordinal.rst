Ordinal
=======

.. autoclass:: category_encoders.ordinal.OrdinalEncoder
    :members:
