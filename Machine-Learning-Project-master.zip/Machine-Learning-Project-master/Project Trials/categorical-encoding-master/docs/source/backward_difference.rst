Backward Difference Coding
==========================

.. autoclass:: category_encoders.backward_difference.BackwardDifferenceEncoder
    :members:
