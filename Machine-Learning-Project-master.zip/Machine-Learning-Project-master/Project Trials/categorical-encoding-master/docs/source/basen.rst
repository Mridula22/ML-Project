BaseN
=====

.. autoclass:: category_encoders.basen.BaseNEncoder
    :members:
