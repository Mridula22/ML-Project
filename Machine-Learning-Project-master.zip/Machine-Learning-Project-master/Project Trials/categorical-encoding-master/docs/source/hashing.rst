Hashing
=======

.. autoclass:: category_encoders.hashing.HashingEncoder
    :members:

