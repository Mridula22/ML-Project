One Hot
=======

.. autoclass:: category_encoders.one_hot.OneHotEncoder
    :members:
