Polynomial Coding
=================

.. autoclass:: category_encoders.polynomial.PolynomialEncoder
    :members:
